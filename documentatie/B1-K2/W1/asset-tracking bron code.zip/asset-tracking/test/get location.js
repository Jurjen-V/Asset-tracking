//map.locate({
//   watch: true,
//   setView: false,
//   maxZoom: 18,
//   enableHighAccuracy: true
// });
// functie om afgelde route te tekenen
// get current location of website visiter
// function onLocationFound(e) {
//   if (i == 0) {
//     map.panTo(new L.LatLng(e.latitude, e.longitude));
//     i = i + 1;
//   }
//   var latlngs = Array();
//   var radius = e.accuracy;
//   if (current_position) {
//     map.removeLayer(current_position);
//     map.removeLayer(circle);
//   }
//   //set location

//   circle = new L.circleMarker(e.latlng, {
//     color: "#4285F4",
//     weight: 0,
//     fillColor: "#4285F4",
//     fillOpacity: 0.5,
//     radius: 20,
//   }).addTo(map);
//   current_position = new L.circleMarker(e.latlng, {
//     color: "white",
//     weight: 2,
//     fillColor: "#4285F4",
//     radius: 10,
//     opacity: 1,
//     fillOpacity: 1,
//   }).addTo(map);
//   map.addLayer(circle);
//   current_position.bindPopup("Latitude: " + e.latitude +"<br>" + "Longitude: " + e.longitude);
//   map.addLayer(current_position);
//   if(count == 0){
//     setTimeout(update(e), 1000);
//   }else{
//     console.log(count);
//     count -= 1;   
//   }
// }
// //set vieuw on yourlocation
// function setview(e) {
//   var latview = e._latlng.lat;
//   var lngview = e._latlng.lng;
//   map.panTo(new L.LatLng(latview, lngview));
// }
// map.on("locationfound", onLocationFound);
// function onLocationError(e) {
//   alert(e.message);
// }
// var line = L.polyline([],{dashArray: '20,15'}).addTo(map);

// function redraw(point) {
//     line.addLatLng(point);
// }
// function update(e) {
//   if(e != null){
//     var loc = [e.latlng];
//     if (loc.length) {
//       redraw(loc.shift());
//       setTimeout(update, 1000);
//     }
//   }
// }
// for (i = 0; i < assets.length; i++) {
//   var apikey = '5b104f01c9434e3dad1e2d6a548445da&language';

//   var api_url = 'https://api.opencagedata.com/geocode/v1/json'

//   var request_url = api_url
//     + '?'
//     + 'key=' + apikey
//     + '&q=' + encodeURIComponent(assets[i])
//     + '&pretty=1'
//     + '&no_annotations=1';
//   console.log(request_url);   
//   // see full list of required and optional parameters:
//   // https://opencagedata.com/api#forward

//   var request = new XMLHttpRequest();
//   request.open('GET', request_url, true);

//   request.onload = function() {
//     // see full list of possible response codes:
//     // https://opencagedata.com/api#codes

//     if (request.status == 200){ 
//       // Success!
//       var data = JSON.parse(request.responseText);
//       console.log(data.results[0]);

//     } else if (request.status <= 500){ 
//       // We reached our target server, but it returned an error
                           
//       console.log("unable to geocode! Response code: " + request.status);
//       var data = JSON.parse(request.responseText);
//       console.log(data.status.message);
//     } else {
//       console.log("server error");
//     }
//   };

//   request.onerror = function() {
//     // There was a connection error of some sort
//     console.log("unable to connect to server");        
//   };

//   request.send();  // make the request
// }
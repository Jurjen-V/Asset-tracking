<footer class="page-footer">
    <div class="container">
    	<div class="row footer">
    		<h5 class="white-text center-align">Powered by</h5>
            <div class="col s6">
            	<!-- link to hawarit -->
            	<a href="https://www.hawarit.com/"><img class="footer-img" src="img/HIT-logo-150.png"></a>
            </div>
            <div class="col s6">
            	<!-- footer link to chaloIS -->
				<a href="https://www.chalois.com/"><img class="footer-img" src="img/chalois_logo.png"></a>
            </div>
        </div>
    </div>
</footer>
